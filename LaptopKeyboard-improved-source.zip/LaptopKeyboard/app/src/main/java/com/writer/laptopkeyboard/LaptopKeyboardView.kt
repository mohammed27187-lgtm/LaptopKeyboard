package com.writer.laptopkeyboard

import android.content.Context
import android.inputmethodservice.Keyboard
import android.inputmethodservice.KeyboardView
import android.util.AttributeSet

class LaptopKeyboardView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0
) : KeyboardView(context, attrs, defStyleAttr) {

    init {
        // Make keys feel a bit more laptop-like
        isPreviewEnabled = false   // no popup preview (cleaner for dense layout)
    }
}
