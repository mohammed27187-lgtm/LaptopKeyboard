package com.writer.laptopkeyboard

import android.inputmethodservice.InputMethodService
import android.inputmethodservice.Keyboard
import android.inputmethodservice.KeyboardView
import android.view.KeyEvent
import android.view.View
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputConnection

class LaptopKeyboardService : InputMethodService(), KeyboardView.OnKeyboardActionListener {

    private lateinit var keyboardView: LaptopKeyboardView
    private lateinit var qwertyKeyboard: Keyboard
    private lateinit var symbolsKeyboard: Keyboard

    private var isShifted = false
    private var isCapsLock = false
    private var isCtrlPressed = false
    private var isAltPressed = false
    private var isSymbols = false

    override fun onCreateInputView(): View {
        keyboardView = layoutInflater.inflate(R.layout.keyboard_view, null) as LaptopKeyboardView
        qwertyKeyboard = Keyboard(this, R.xml.qwerty)
        symbolsKeyboard = Keyboard(this, R.xml.symbols)

        keyboardView.keyboard = qwertyKeyboard
        keyboardView.setOnKeyboardActionListener(this)
        keyboardView.isPreviewEnabled = false

        return keyboardView
    }

    override fun onStartInputView(info: EditorInfo?, restarting: Boolean) {
        super.onStartInputView(info, restarting)
        // Reset modifiers when starting a new input field
        isShifted = false
        isCapsLock = false
        isCtrlPressed = false
        isAltPressed = false
        isSymbols = false
        keyboardView.keyboard = qwertyKeyboard
        updateShiftKey()
    }

    override fun onKey(primaryCode: Int, keyCodes: IntArray?) {
        val ic: InputConnection = currentInputConnection ?: return

        when (primaryCode) {
            Keyboard.KEYCODE_DELETE -> {
                ic.deleteSurroundingText(1, 0)
            }

            Keyboard.KEYCODE_SHIFT -> {
                when {
                    isCapsLock -> {
                        isCapsLock = false
                        isShifted = false
                    }
                    isShifted -> {
                        // Second press → Caps Lock
                        isCapsLock = true
                        isShifted = true
                    }
                    else -> {
                        isShifted = true
                    }
                }
                updateShiftKey()
            }

            // Arrow keys
            -2 -> sendDownUpKeyEvents(KeyEvent.KEYCODE_DPAD_DOWN)      // ↓
            -3 -> sendDownUpKeyEvents(KeyEvent.KEYCODE_DPAD_LEFT)      // ←
            -8 -> sendDownUpKeyEvents(KeyEvent.KEYCODE_DPAD_UP)        // ↑
            -9 -> sendDownUpKeyEvents(KeyEvent.KEYCODE_DPAD_RIGHT)     // →

            // Enter
            -4 -> {
                val action = currentInputEditorInfo?.imeOptions?.and(EditorInfo.IME_MASK_ACTION)
                    ?: EditorInfo.IME_ACTION_UNSPECIFIED
                if (action == EditorInfo.IME_ACTION_SEARCH ||
                    action == EditorInfo.IME_ACTION_GO ||
                    action == EditorInfo.IME_ACTION_SEND ||
                    action == EditorInfo.IME_ACTION_DONE
                ) {
                    ic.performEditorAction(action)
                } else {
                    ic.sendKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, KeyEvent.KEYCODE_ENTER))
                    ic.sendKeyEvent(KeyEvent(KeyEvent.ACTION_UP, KeyEvent.KEYCODE_ENTER))
                }
            }

            // Ctrl toggle
            -6 -> {
                isCtrlPressed = !isCtrlPressed
            }

            // Alt toggle
            -7 -> {
                isAltPressed = !isAltPressed
            }

            // Switch to ABC (from symbols)
            -10 -> {
                isSymbols = false
                keyboardView.keyboard = qwertyKeyboard
            }

            // Home / End
            -11 -> sendDownUpKeyEvents(KeyEvent.KEYCODE_MOVE_HOME)
            -12 -> sendDownUpKeyEvents(KeyEvent.KEYCODE_MOVE_END)

            // ?123 → symbols layer
            -13 -> {
                isSymbols = true
                keyboardView.keyboard = symbolsKeyboard
            }

            else -> {
                var code = primaryCode

                // Ctrl combinations – very useful for Excel & writing
                if (isCtrlPressed) {
                    when (code) {
                        97, 65 -> { // Ctrl + A → Select All
                            ic.performContextMenuAction(android.R.id.selectAll)
                            isCtrlPressed = false
                            return
                        }
                        99, 67 -> { // Ctrl + C → Copy
                            ic.performContextMenuAction(android.R.id.copy)
                            isCtrlPressed = false
                            return
                        }
                        118, 86 -> { // Ctrl + V → Paste
                            ic.performContextMenuAction(android.R.id.paste)
                            isCtrlPressed = false
                            return
                        }
                        120, 88 -> { // Ctrl + X → Cut
                            ic.performContextMenuAction(android.R.id.cut)
                            isCtrlPressed = false
                            return
                        }
                        122, 90 -> { // Ctrl + Z
                            // Best-effort undo via key event
                            val event = KeyEvent(0, 0, KeyEvent.ACTION_DOWN,
                                KeyEvent.KEYCODE_Z, 0, KeyEvent.META_CTRL_ON)
                            ic.sendKeyEvent(event)
                            ic.sendKeyEvent(KeyEvent.changeAction(event, KeyEvent.ACTION_UP))
                            isCtrlPressed = false
                            return
                        }
                    }
                }

                // Apply shift / caps
                if ((isShifted || isCapsLock) && Character.isLetter(code)) {
                    code = Character.toUpperCase(code)
                }

                ic.commitText(code.toChar().toString(), 1)

                // Auto-turn off shift after one character (unless Caps Lock)
                if (isShifted && !isCapsLock) {
                    isShifted = false
                    updateShiftKey()
                }

                // Clear one-shot modifiers
                isCtrlPressed = false
                isAltPressed = false
            }
        }
    }

    private fun updateShiftKey() {
        val shifted = isShifted || isCapsLock
        keyboardView.isShifted = shifted
        qwertyKeyboard.isShifted = shifted
        keyboardView.invalidateAllKeys()
    }

    private fun sendDownUpKeyEvents(keyCode: Int) {
        val ic = currentInputConnection ?: return
        ic.sendKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, keyCode))
        ic.sendKeyEvent(KeyEvent(KeyEvent.ACTION_UP, keyCode))
    }

    // Required stubs
    override fun onPress(primaryCode: Int) {}
    override fun onRelease(primaryCode: Int) {}
    override fun onText(text: CharSequence?) {
        currentInputConnection?.commitText(text, 1)
    }
    override fun swipeLeft() {}
    override fun swipeRight() {}
    override fun swipeDown() {}
    override fun swipeUp() {}
}
