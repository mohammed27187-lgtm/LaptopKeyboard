# Keep the Input Method Service
-keep class com.writer.laptopkeyboard.LaptopKeyboardService { *; }
